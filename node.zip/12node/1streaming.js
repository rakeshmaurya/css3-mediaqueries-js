console.log("Stream Reading....");

var fs = require("fs");
var mydata = '';
var readStream = fs.createReadStream('file1.txt');
// var readStream = fs.createReadStream('myfile1.txt');
readStream.setEncoding('UTF8');

readStream.on('data', function(chunkData) {
  // console.log("  *** This is Chunk ******************************************************************* ", chunkData);
   mydata += "*******************" + chunkData;
   //console.log(chunkData);
  // var len = chunkData.length;
   //
  // console.log("DATA LENGTH" , len);
});

readStream.on('end',function(){
   console.log('End event triggered');
   console.log(mydata);
});

readStream.on('error', function(err){
   console.log(err.stack);
});

console.log("App ended here ....!!");