console.log('How to define a  variable');
var sale = 3600;
var tax = 150;
console.log('Sales Value : ', sale, "Tax Values : ", tax);
