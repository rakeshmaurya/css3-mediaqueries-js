exports.var1="rakesh maurya"

exports.ar={"name":"ravi"};
module.exports.func1= function(){
	
	return 50;
};