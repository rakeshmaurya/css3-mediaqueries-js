buf = new Buffer(26);
for (var i = 0 ; i < 26 ; i++) {
  
  buf[i] = i + 65;
 // console.log( i+65);
 console.log( buf[i]);
}

console.log( buf);
console.log( buf.toString('ascii'));       
console.log( buf.toString('ascii',0,10));   
console.log( buf.toString('utf8',0,15));   
console.log( buf.toString(undefined,0,15)); 