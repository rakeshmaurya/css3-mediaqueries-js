 var http=require("http");
 var server=http.createServer(function(req, res){
	 
	 res.write("fda" + req.url);
	 res.end();
	 console.log("FDA");
	 
 });
 
 server.listen(2000);