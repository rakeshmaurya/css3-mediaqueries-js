console.log("Stream piping....");
var fs = require("fs");

var readStream1 = fs.createReadStream('myfile2.txt');
var readStream2 = fs.createReadStream('myfile.txt');

var writeStream = fs.createWriteStream('output.txt');
//

//readStream2.pipe(readStream1.pipe(writeStream));

readStream2.pipe(writeStream);
readStream1.pipe(writeStream);

console.log("Program Ended");