(function(controllers) {

var homeController = require("./homeController");
var ServiceController = require("./serviceController");

controllers.init = function(app) {
	homeController.init(app);
	ServiceController.init(app);
};


})(module.exports);
