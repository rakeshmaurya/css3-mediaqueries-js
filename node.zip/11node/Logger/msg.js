module.exports.msgLog = function(msg) { 
console.log(msg);
};