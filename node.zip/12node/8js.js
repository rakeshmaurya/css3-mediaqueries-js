function printHello(){
   console.log( "Hi I am Learning Node.JS");
}

setTimeout(printHello, 3000);

var t = setTimeout(printHello, 1000);

clearTimeout(t,2000);