var express		=	require('express');
var session		=	require('express-session');
var bodyParser  = 	require('body-parser');
var app			=	express();

app.use(express.static(__dirname + '/public'));

app.set('views', __dirname + '/views');
app.engine('html', require('ejs').renderFile);
app.use(session({secret: 'adakjfhksjfhkjsk',saveUninitialized: true,resave: true}));
app.use(bodyParser.json());      
app.use(bodyParser.urlencoded({extended: true}));

var sess;

app.get('/',function(req,res){
	sess = req.session;
	if(sess.email)
	{
		res.redirect('/admin');
	}
	else{
	res.render('index.html');
	}
});

app.post('/login',function(req,res){
	
	sess=req.session;	
	sess.email=req.body.email;
	sess.pwd = req.body.pass;
	if (sess.email == "test@gmail.com")
	{
		res.end('done');
	}
	else
	{
		req.session.destroy(function(err){
		if(err){
			console.log(err);
		}
		else
		{
			console.log('destroyed');
			///res.redirect('/');
		}
		});
		res.end('notdone');
	}
	
});

app.get('/admin',function(req,res){
	sess=req.session;
	if(sess.email)	
	{
		res.write('<h1>Hello logged email : '+sess.email+'</h1><br>');
		res.write('<h1>Hello logged password :'+sess.pwd+'</h1><br>');
		res.end('<a href='+'/logout'+'>Logout</a>');
	}
	else
	{
		res.write('<h1>Please login first.</h1>');
		res.end('<a href='+'/'+'>Login</a>');
	}

});

app.get('/logout',function(req,res){
	
	req.session.destroy(function(err){
		if(err){
			console.log(err);
		}
		else
		{
			console.log('destroyed');
			res.redirect('/');
		}
	});

});
app.listen(3000,function(){
	console.log("App Started on PORT 3000");
});
