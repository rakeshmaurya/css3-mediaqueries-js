var app = angular.module('myApp', []);
app.controller('userCtrl', function($scope) {
$scope.fName = '';
$scope.lName = '';
$scope.passw1 = '';
$scope.passw2 = '';

$scope.users = [
{id:1, fName:'Amit',� lName:"Sharma" },
{id:2, fName:'Karan',�� lName:"Sharma" },
{id:3, fName:'Rajesh',�� lName:"Chauhan" },
{id:4, fName:'Manish',� lName:"Rajput" },
{id:5, fName:'Seema',� lName:"Sharma" },
{id:6, fName:'Ajit', lName:"Patel" }
];

$scope.edit = true;
$scope.error = false;

$scope.editUser = function(id) {
� if (id == 'addnew') {
��� $scope.edit = true;
��� $scope.fName = 'rakehsh';
��� $scope.lName = '';
��� } else {
��� $scope.edit = false;
��� $scope.fName = $scope.users[id-1].fName;
��� $scope.lName = $scope.users[id-1].lName; 
� }
};



})