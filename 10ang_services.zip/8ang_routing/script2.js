var app = angular.module('RoutingApp', ['ngRoute'])
app.config( ['$routeProvider', function($routeProvider) {
		$routeProvider
			.when('/first', {
				templateUrl: 'first1.html',
				controller:'firstController'				
			})
			.when('/second', {
				templateUrl: 'second1.html',
				controller:'secondController'
			})
			.when('/third', {
				templateUrl: 'third1.html',
				controller:'thirdController'
			})
			.when('/forth', {
				templateUrl: 'forth1.html',
				controller:'forthController'
			})
			.when('/login', {
				templateUrl: 'login.html',
				controller:'LoginController'
			})
			.otherwise({
				redirectTo: '/first'
			});
	}]);

app.controller('firstController',function($scope)
{
	$scope.Message = 'Hello .... Congratulations you accessed First Controller';
});

app.controller('secondController',function($scope, $rootScope)
{
	$scope.submit = function(){
		$rootScope.rsMobile = $scope.mobileno;
		
	}
	$scope.Message = 'Congratulations you accessed Second Controller ';
});

app.controller('thirdController', function($scope)
{
	$scope.Message = 'Congratulations you accessed Third Controller ';
});

app.controller('forthController',function($scope,$rootScope)
{
	$scope.mob = $rootScope.rsMobile;
	$scope.Message = 'Congratulations you accessed Forth Controller ';
});

app.controller('LoginController',function($scope, $window)
{
	$scope.Submit = function(user,pwd)
	{
		$scope.userDetails = "Logged User :" + user + " password " + pwd;
		$window.location.href="project2.html#/first";
	}
	
});
