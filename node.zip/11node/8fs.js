var fs = require("fs");
var data = fs.readFileSync('mytextfile.txt');
console.log(data.toString());
console.log("Program Ended");

