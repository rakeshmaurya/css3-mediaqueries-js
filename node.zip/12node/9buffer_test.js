
var buffer1 = new Buffer(10);
console.log("buffer3 content: " + buffer1);
console.log(buffer1);