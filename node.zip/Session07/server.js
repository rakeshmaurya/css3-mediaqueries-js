var express = require('express');
app = express();

var controller = require("./controllers");

app.set("view engine", "jade");
controller.init(app);
app.listen(2000);

