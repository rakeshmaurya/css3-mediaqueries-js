console.log("Chaining stream example");

var fs = require("fs");
var zlib = require('zlib');

console.log("Going to read a file ...");



// zip
// fs.createReadStream('myfile.txt')
//   .pipe(zlib.createGzip())
//   .pipe(fs.createWriteStream('myfile.zip'));

// console.log("File has been compressed successfully......!!");


// //rar
 //fs.createReadStream('myfile.txt')
   //.pipe(zlib.createGzip())
   //.pipe(fs.createWriteStream('myfile.rar'));
  //console.log("File has been compressed successfully......!!");


fs.createReadStream('myfile.zip')
.pipe(zlib.createGunzip())
.pipe(fs.createWriteStream('myfile123.txt'));

console.log("File has been unzipped successfully......!!");

