nvar express = require('express');
var app = express();

var port =  4000;

// create express middleware
app.use(function(req, res) {
  var data = '<h1>hello node.js world I am learning</h1>';
  res.writeHead(200, { 'Content-Type': 'text/html' });
  res.end(data);
});

app.listen(port);

console.log('server started on port ');