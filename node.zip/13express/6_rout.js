var app = require('express')(),
    port = 3000;

app.get('/page1', function(req, res) {
  res.send('<h1>hello world</h1>');             
});

app.get('/page2', function(req, res) {
  res.header('Content-Type', 'text/plain');
  res.send('hello world\n');                    
});

app.get('/page3', function(req, res) {
  res.send(new Buffer('hello world\n'));        
});

app.get('/page4', function(req, res) {
  res.header('Content-Type', 'text/json');
  res.send({message: 'hello world',Remarks: 'Remark is ok'});         
});

app.get('/page5', function(req, res) {
  res.send(['hello world','node.js','AngularJS']);                  
});

app.get('/page6', function(req, res) {
  res.header('Content-Type', 'text/xml');
  res.send('<message>hello world</message>')    
});

app.listen(port);