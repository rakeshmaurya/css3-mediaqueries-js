module.exports.indexLog = function(msg) { 
	require("./msg.js");
	//require("./msg.js");
	//require("./msg.js");
	// console.log(msg);
	
};