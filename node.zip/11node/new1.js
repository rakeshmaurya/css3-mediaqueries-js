var myhttp=require("http");
var server=myhttp.createServer(function (req,res){
res.write("<h1>my first app</h1>");
res.end();
});
server.listen(3000);