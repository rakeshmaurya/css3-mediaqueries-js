(function(homeController) {
	
homeController.init = function (app) {

app.get("/home",function(req, res){
	res.render("Index", {title : "This is title coming from Home Controller"});
});

};
})(module.exports);