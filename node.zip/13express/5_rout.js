var app = require('express')();
    port =  3000;

app.get('/', function(req, res) {

  res.send('<h1>Welcome to Express Now we are on home page ....!!</h1>');
});

app.get('/about', function(req, res) {
  res.send('<h1>I am learning node.js using expess now about page called for testing</h1>');
});

app.get('/service', function(req, res) {
  res.send('<h1>I am learning node.js using expess now Service page called for testing</h1>');
});

app.get('/contact', function(req, res) {
  var htmldata = '<label> Enter User Name </label> <input type="text" />';
  res.send(htmldata);
});

app.listen(port);