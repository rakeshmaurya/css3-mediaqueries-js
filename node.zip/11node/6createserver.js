var myhttp = require("http");
var myserver =  myhttp.createServer(function (reqest, response) {
// to write on node console	
console.log("Application started");
console.log("we are using this URL :...... ", reqest.url);
// to write on browser
response.write("<html><body><h1>" + "This is text web page created by node.js URL :  " +  reqest.url + "</h1></body></html>");
response.end();
});

myserver.listen(2000);