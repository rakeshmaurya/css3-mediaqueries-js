// var buf = new Buffer(100);
// var buf;
// console.log(buf);


var buffer1 = new Buffer(10);
//var buffer2 = new Buffer('def');
//var buffer3 = Buffer.concat([buffer1,buffer2]);
console.log("buffer3 content: " + buffer1);