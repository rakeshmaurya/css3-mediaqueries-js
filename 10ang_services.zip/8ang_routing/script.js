   var app = angular.module('RoutingApp', ['ngRoute']);

   app.config( ['$routeProvider', function($routeProvider) {
		$routeProvider
		.when('/', {
			templateUrl: 'first.html'
		})
			.when('/first', {
				templateUrl: 'first.html'
			})
			.when('/second', {
				templateUrl: 'second.html'
			})
			.when('/third', {
				templateUrl: 'third.html'
			})
			.when('/forth', {
				templateUrl: 'forth.html'
			})
			/*.otherwise({
				//templateUrl: 'error.html'
				// redirectTo: '/first'
			}) */
			;
	}]);