console.log('How to read a variable define in External JS file');

var msgs =  require("./msg.js");
var test= require("./test.js");
console.log(test.ar.name);

console.log(msgs.first);
console.log(msgs.second);

console.log('How to read a variable define in External JS file in JSON format');
console.log(msgs.third.name);
console.log(msgs.third.address);
