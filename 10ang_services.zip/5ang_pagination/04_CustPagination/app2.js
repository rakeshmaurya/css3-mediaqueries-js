var app = angular.module('angularTable', ['angularUtils.directives.dirPagination']);


app.controller('listdata',['$scope','$http',function($scope, $http){
//declare an empty array
$scope.clients = [{"id":1,"name":"Amit","bal":25000},
{"id":2,"name":"Avish","bal":35000},
{"id":3,"name":"Tara","bal":35000},
{"id":4,"name":"Pradeep","bal":35000},
{"id":5,"name":"Jagat","bal":35000},
{"id":6,"name":"Suresh","bal":35000},
{"id":7,"name":"Adarsh","bal":35000},
{"id":8,"name":"Gaurav","bal":35000},
{"id":9,"name":"Raman","bal":35000},
{"id":10,"name":"BalVeer","bal":35000},
{"id":11,"name":"Satverr","bal":35000},
{"id":12,"name":"Anant","bal":35000},
{"id":13,"name":"Meena","bal":35000},
{"id":14,"name":"Lata","bal":35000}];

$scope.pgTotal =0;
$scope.total = GetTotal($scope.clients);

 function GetTotal(clientCollection) {
            var tot = 0;
            angular.forEach(clientCollection, function (item) {
                tot += item.bal;
           })
            return tot;
        }

$scope.pgNumbers = function pgNumber(a)
{
	$scope.myPageSize=a;
}


$scope.sort = function(keyname){
		
$scope.sortKey = keyname;  
 //set the sortKey to the param passed
		
$scope.reverse = !$scope.reverse;
 //if true make it false and vice versa
	
}


}]);