console.log('How to call function defined in External JS file');
var message2 = require("./msg2.js");
console.log(message2.disp());

console.log(message2.disp2());

