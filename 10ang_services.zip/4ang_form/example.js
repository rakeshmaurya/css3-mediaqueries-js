angular.module('myapp', ['ui.bootstrap']);

angular.module('myapp').controller('AlertDemoCtrl', function ($scope) {
 
 $scope.alerts = [
    { csstype: 'primary', msg: 'Oh snap! Change a few things up and try submitting again.' },
    { csstype: 'success', msg: 'Well done! You successfully read this important alert message.' },
    { csstype: 'info', msg: 'Please enter first Name.' },
  ];

  
$scope.addAlert = function(txtmsg, txttype) {
    
	$scope.alerts.push({type: txttype,msg: txtmsg});
  
};

  
$scope.closeAlert = function(index) {
	$scope.alerts.splice(index, 1);
 
 };
 
});