module.exports.disp = function() {
return "This is Function is called from msg2.js file";
};

module.exports.disp2 = function() {
return "This is Function 2 is called from msg2.js file";
};