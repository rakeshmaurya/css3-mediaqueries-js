//var http = require("http");
var MongoClient = require('mongodb').MongoClient;
var express = require("express");
var app = express();


var bodyParser = require('body-parser');
app.use(bodyParser.json());
app.use(bodyParser.urlencoded({ extended: false }));
app.set("view engine", "jade");

var data = "";
var htmldata = "";

app.get("/custlist", function (req, res) {
		console.log("addment");
    htmldata = htmldata + "</table>";
    res.send(htmldata);
});

app.get("/newcust", function (req, res) {
    res.render("newcust", { title: "Add New customer + Jade" });
});

app.post("/addcust", function (req, res) {
	console.log("add");
    var cname = req.body.custname;
    var add = req.body.address;
    MongoClient.connect("mongodb://localhost:27017/mydb", function (err, db) {
        var collection = db.collection("mycol2");
       
         collection.insert({ "custname": cname, "address": add }, function (err, doc) {
           if (err) {
                res.send("There is error in writing in db");
            }
            else {
                res.redirect("custlist");
            }
        }
        );

    });
});



app.get("/delcust", function (req, res) {
    res.render("delcust", { title: "Express2 + Jade" });
});

app.post("/delcust", function (req, res) {
    var cname = req.body.custname;
    MongoClient.connect("mongodb://localhost:27017/mydb", function (err, db) {
        var collection = db.collection("mycol2");
        collection.remove({ 'custname': cname }, function (err) {
            res.send((err === null) ? { msg: 'Record Deleted' } : { msg: 'error: ' + err });
        });
        
    });
});


app.get("/updcust", function (req, res) {
    res.render("updcust", { title: "updating customer + Jade" });
});

app.post("/updcust", function (req, res) {
    var cname = req.body.custname;
    var add = req.body.address;
    MongoClient.connect("mongodb://localhost:27017/mydb", function (err, db) {
        var collection = db.collection("mycol2");
        collection.update({ 'custname': cname }, { $set: { 'address': add } });
        res.redirect("custlist");
    });
});


// Connect to the db
MongoClient.connect("mongodb://localhost:27017/mydb", function (err, db) {
    //console.log("Connecting to server");
    if (!err) {
        var collection = db.collection("mycol2");
        //console.log("We are connected");
        //console.log("database",db);
        var cursor = collection.find();
        data = "<table style='border: 0px solid grey;color:Red;margin-left:30px;font-size:20px;width:80%'>";
        data = data + "<th>Customer ID</th><th>Customer Name</th><th>Address</th>";
        cursor.each(function (err, doc) {
            if (doc) {
                if (err) {
                    console.log(err);
                } else {
                    //console.log('Fetched: Customer Name : ', doc.custname, "Address ", doc.address);
                    data = data + "<tr>";

                    data = data + "<td style='border: 1px solid grey'>";
                    data = data + doc._id + "";
                    data = data + "</td>";

                    data = data + "<td style='border: 1px solid grey'>";
                    data = data + doc.custname + "";
                    data = data + "</td>";

                    data = data + "<td style='border: 1px solid grey'>";
                    data = data + doc.address + "";
                    data = data + "</td>";
/*
                    data = data + "<td style='border: 1px solid grey'>";
                    data = data + doc.phone + "";
                    data = data + "</td>";*/

                    data = data + "</tr>";
                    htmldata = htmldata + data;
                    data = "";
                    //console.log(data);
                    //console.log(htmldata);
                }
            }
        });
        htmldata = htmldata + "</table>";
        //console.log(htmldata);
    }
});

//var server = http.createServer(app);
app.listen(3000);