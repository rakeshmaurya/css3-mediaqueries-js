console.log("Stream Writing....");
var fs = require("fs");

//var data = 'Node.js Learning is fun';
var mydata ='';
//var data = '';
var readerStream = fs.createReadStream('myfile1.txt');
readerStream.setEncoding('UTF8');

readerStream.on('data', function(chunk) {
   //console.log("  *** This is Chunck *** ",chunk.length);
   //console.log("  *** This is Chunck *** ",chunk);
   //watch(chunk);
   mydata += "*** textdata ***" + chunk;
  
  
});
//mydata += data;

readerStream.on('end',function(){
var writerStream = fs.createWriteStream('output.txt');
writerStream.write(mydata,'UTF8');
writerStream.end();
});

console.log("Program Ended");