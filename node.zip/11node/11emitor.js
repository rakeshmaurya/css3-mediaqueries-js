var events = require('events');

var eventEmitter = new events.EventEmitter(); // we create sender here

var connectHandler = function connected() {
   console.log('connection done succesfully.');
   eventEmitter.emit('evntdatareceived');
}

eventEmitter.on('evntconnection', connectHandler);

eventEmitter.on('evntdatareceived', function(){
   console.log('data received succesfully.');
});

eventEmitter.emit('evntconnection');

console.log("Program Ended.");