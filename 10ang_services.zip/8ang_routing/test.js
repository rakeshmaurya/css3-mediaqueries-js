   var app = angular.module('RoutingApp', ['ngRoute']);

   app.config(function($routeProvider){
	   $routeProvider
	   .when('/',{
		   templateUrl:'first.html',
	   })
	   .when('/first',{
		   templateUrl:'first.html',
	   })
	   .when('/second',{
		   templateUrl:'second.html',
	   })
	   
	   
	   
   });