var events = require('events');

var eventEmitter = new events.EventEmitter(); // we create eventEmitter object here






var connectHandler1 = function connected() {
   console.log('connection done succesfully.');
   eventEmitter.emit('evntdatareceived');
};

var connectHandler2= function(){
   console.log('data received succesfully.');
   
}


eventEmitter.on('evntconnection', connectHandler1);// listener function. evntconnection is event name and connectHandler1 is event hander

eventEmitter.on('evntdatareceived', connectHandler2 );


eventEmitter.emit('evntconnection'); // event "evntconnection" gets fired


console.log("Program Ended.");