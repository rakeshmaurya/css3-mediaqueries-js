var express = require('express'),
    app = express(),
    port = 3000;

// app.use(function (req, res, next) {
//   console.log(req.url);
//   next();
// });

app.use('/user/:id', function(req, res, next) {
  console.log('Request URL:', req.originalUrl);
   next();
}, function (req, res, next) {
  console.log('Request Type:', req.method);
  next();
});

app.get('/user/:uid', function (req, res) {
  var userid = req.params.uid;
  res.send('USER is called : ID  ' + userid);
});

app.get('/emp/:eid', function (req, res) {
  var userid =req.params.eid;
  res.send('Employee is called : ID  ' + userid);
});

app.listen(port);

