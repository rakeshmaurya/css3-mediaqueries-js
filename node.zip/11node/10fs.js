var fs = require("fs");

fs.readFile('mytextfile.txt', function (err, data) {
   if (err){
      console.log("Error in reading text file ");
      return;
   }
   console.log(data.toString());
});
console.log("Program Ended");