console.log("Please wait for 5 sec to answer");

function printHello(){
   console.log( "Hi, I am learning node.js");
}

setTimeout(printHello, 5000);