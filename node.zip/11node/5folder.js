console.log('Reading a values from a folder');


var logger =  require("./logger");
logger.indexLog("This is new message from logger passed to index.js");
//logger.msgLog("This is new message from logger passed to indexmnknklk.js");

// console.log('Reading a values from a folder contains msg.js file');
 //var log = require("./logger/msg.js");
  //log.msgLog("this is message from logMsg function file used msg.js");