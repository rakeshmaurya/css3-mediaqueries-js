console.log("display directory");
console.log( __dirname );

