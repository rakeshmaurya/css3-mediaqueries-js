var buf = new Buffer(35);

len = buf.write("I am learning Angular.js");

console.log("Octets written : "+  buf);

console.log("Octets written : "+  len);

len = buf.write("Rahul");

console.log("Octets written : "+  buf);
console.log("No of Octets written : "+  len);
