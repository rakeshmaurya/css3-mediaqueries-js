var express = require('express'),
    app = express(),
    port = 2000;

// route handler for GET /
app.get('/home', function(req, res) {
  var data = '<h1>This is home page I am learning node.js</h1>';
  res.send(data);
});

app.listen(port);

console.log('server started on port %s', port);
