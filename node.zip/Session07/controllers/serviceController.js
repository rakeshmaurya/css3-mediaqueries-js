(function(serviceController) {
serviceController.init = function (app) {

app.get("/service",function(req, res){
	res.render("Index", {title : "This is title coming from Service Controller"});
});

};
})(module.exports);