exports.first = "this is the first messsage";
exports.second = "this is the second messsage";
exports.third = {name:"This is my name Node.js",address:'Delhi India'};
